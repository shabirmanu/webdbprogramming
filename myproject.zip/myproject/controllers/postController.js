const pool = require('../config/dbConfig');

const createPost = async (title, content, author) => {
  try {
    const connection = await pool.getConnection();
    const result = await connection.query('INSERT INTO posts (title, content, author) VALUES (?, ?, ?)', [title, content, author]);
    connection.release();
    return result;
  } catch (error) {
    throw error;
  }
};

const getAllPosts = async () => {
  try {
    const connection = await pool.getConnection();
    const result = await connection.query('SELECT * FROM posts');
    connection.release();
    return result;
  } catch (error) {
    throw error;
  }
};

const getPostById = async (postId) => {
  try {
    const connection = await pool.getConnection();
    const result = await connection.query('SELECT * FROM posts WHERE id = ?', [postId]);
    connection.release();
    return result[0];
  } catch (error) {
    throw error;
  }
};


const updatePost = async (postId, newContent, author) => {
    try {
      const connection = await pool.getConnection();
      const result = await connection.query('UPDATE posts SET content = ? WHERE id = ? AND author = ?', [newContent, postId, author]);
      connection.release();
      return result;
    } catch (error) {
      throw error;
    }
  };
  
  const deletePost = async (postId, author) => {
    try {
      const connection = await pool.getConnection();
      const result = await connection.query('DELETE FROM posts WHERE id = ? AND author = ?', [postId, author]);
      connection.release();
      return result;
    } catch (error) {
      throw error;
    }
  };
  
  module.exports = {
    createPost,
    getAllPosts,
    getPostById,
    updatePost,
    deletePost
  };
  
