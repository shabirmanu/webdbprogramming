const pool = require('../config/dbConfig');

const createUser = async (username, password) => {
  try {
    const connection = await pool.getConnection();
    const result = await connection.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
    connection.release();
    return result;
  } catch (error) {
    throw error;
  }
};

const findUserByUsername = async (username) => {
  try {
    const connection = await pool.getConnection();
    const result = await connection.query('SELECT * FROM users WHERE username = ?', [username]);
    connection.release();
    return result[0];
  } catch (error) {
    throw error;
  }
};

module.exports = {
  createUser,
  findUserByUsername
};
