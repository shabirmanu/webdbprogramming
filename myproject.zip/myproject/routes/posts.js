const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { authenticateUser } = require('../middlewares/authMiddleware');
const { isAdmin } = require('../middlewares/adminMiddleware');

router.get('/create', authenticateUser, (req, res) => {
  res.render('createPost');
});

router.post('/create', authenticateUser, async (req, res) => {
  const { title, content } = req.body;
  const author = req.session.user.username;

  try {
    await postController.createPost(title, content, author);
    res.redirect('/');
  } catch (error) {
    res.status(500).send('Internal Server Error');
  }
});

router.get('/', async (req, res) => {
  try {
    const posts = await postController.getAllPosts();
    res.render('home', { posts });
  } catch (error) {
    res.status(500).send('Internal Server Error');
  }
});

router.get('/edit/:postId', authenticateUser, async (req, res) => {
  const postId = req.params.postId;

  try {
    const post = await postController.getPostById(postId);

    if (!post) {
      return res.status(404).send('Post not found');
    }

    // Check if the current user is the author of the post
    if (post.author !== req.session.user.username) {
      return res.status(403).send('Permission denied');
    }

    res.render('editPost', { post });
  } catch (error) {
    res.status(500).send('Internal Server Error');
  }
});

router.post('/edit/:postId', authenticateUser, async (req, res) => {
  const postId = req.params.postId;
  const newContent = req.body.content;

  try {
    await postController.updatePost(postId, newContent);
    res.redirect('/');
  } catch (error) {
    res.status(500).send('Internal Server Error');
  }
});

router.post('/delete/:postId', [authenticateUser, isAdmin], async (req, res) => {
  const postId = req.params.postId;

  try {
    await postController.deletePost(postId);
    res.redirect('/');
  } catch (error) {
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;
