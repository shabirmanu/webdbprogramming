const isAdmin = (req, res, next) => {
    // Assume you have a field in the user table that indicates whether a user is an admin.
    if (req.session.user && req.session.user.isAdmin) {
      next();
    } else {
      res.status(403).send('Permission denied');
    }
  };
  
  module.exports = { isAdmin };
  