const mariadb = require('mariadb');

const pool = mariadb.createPool({
  host: 'your-database-host',
  user: 'your-username',
  password: 'your-password',
  database: 'your-database-name',
  connectionLimit: 5
});

module.exports = pool;
