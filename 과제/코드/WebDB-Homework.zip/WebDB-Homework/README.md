# Web DB Programming

201835715 이재호

views 폴더의 contact.ejs, index.ejs와 scripts 폴더의 contact.js와 index.js 파일을 작업했습니다.